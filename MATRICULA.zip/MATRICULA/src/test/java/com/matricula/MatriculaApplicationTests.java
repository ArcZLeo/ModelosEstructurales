package com.matricula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatriculaApplicationTests {

    @Test
    void contextLoads() {
    }

}
