package com.matricula.model;

import javax.persistence.*;


@Entity
@Table(name = "profesor")
public class Profesor {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 100)
    private String apellido;

    @Column(nullable = false, length = 100)
    private String direccion;

    @Column(nullable = false, length = 9)
    private Integer telefono;

    @Column(nullable = false, length = 100)
    private String dni;

    @Column(nullable = false, length = 100)
    private String area;


}
