package com.matricula.model;

import javax.persistence.*;

@Entity
@Table(name = "aula")
public class Aula {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String pabellon;

    @Column(nullable = false)
    private Integer num_aula;

    @ManyToOne
    @JoinColumn(name ="cod_profesor", nullable = false)
    private Profesor profesor;

    @ManyToOne
    @JoinColumn(name ="cod_aula", nullable = false)
    private Aula aula;

}
