package com.matricula.model;

import javax.persistence.*;

@Entity
@Table(name = "curso")
public class Curso {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 100)
    private Integer semestre;

    @Column(nullable = false)
    private Integer cantidadCreditos;


    public Integer getCantidadCreditos() {
        return cantidadCreditos;
    }

    public void setCantidadCreditos(Integer cantidadCreditos) {
        this.cantidadCreditos = cantidadCreditos;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSemestre() {
        return semestre;
    }

    public void setSemestre(Integer semestre) {
        this.semestre = semestre;
    }
}
