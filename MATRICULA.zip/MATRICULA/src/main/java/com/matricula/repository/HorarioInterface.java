package com.matricula.repository;

import com.matricula.model.Horario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorarioInterface extends JpaRepository<Horario,Long> {
}
