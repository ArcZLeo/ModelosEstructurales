package com.matricula.repository;

import com.matricula.model.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorInterface extends JpaRepository<Profesor,Long> {
}
