package com.matricula.repository;

import com.matricula.model.Alumno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlumnoInterface extends JpaRepository<Alumno,Long> {
}
