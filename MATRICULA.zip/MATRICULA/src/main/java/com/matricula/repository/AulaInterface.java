package com.matricula.repository;

import com.matricula.model.Aula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AulaInterface extends JpaRepository<Aula,Long> {
}
