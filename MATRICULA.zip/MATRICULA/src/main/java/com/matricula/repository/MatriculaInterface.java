package com.matricula.repository;

import com.matricula.model.Matricula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatriculaInterface extends JpaRepository<Matricula,Long> {
}
