package com.matricula.repository;

import com.matricula.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoInterface extends JpaRepository<Curso,Long> {
}
