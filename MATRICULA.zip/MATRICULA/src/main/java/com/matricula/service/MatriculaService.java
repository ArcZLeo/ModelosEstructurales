package com.matricula.service;


import com.matricula.model.Curso;
import com.matricula.model.Horario;
import com.matricula.model.Matricula;
import com.matricula.service.CursoService;
import com.matricula.repository.MatriculaInterface;

import com.matricula.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

@Service
public class MatriculaService implements MatriculaInterface {
    @Autowired
    private MatriculaInterface matriculaInterface;

    @Autowired
    private CursoService cursoService;

    @Override
    public List<Matricula> findAll() {
        return matriculaInterface.findAll();
    }

    @Override
    public Optional<Matricula> findById(Long aLong) {
        return matriculaInterface.findById(aLong);
    }

    public List<String> findByName(){
        List<String> alumnosNombre=new ArrayList<>();
        List<Matricula> matriculados = matriculaInterface.findAll();
        for (int i=0; i<matriculados.size(); i++) {
            alumnosNombre.add(matriculados.get(i).getAlumno().getNombre());
        }
        return alumnosNombre;
    }

    public boolean validarMatricula(Long aLong){
        Optional<Matricula> alumnoMatriculado = matriculaInterface.findById(aLong);
        if(alumnoMatriculado.get().getAlumno().getEstado()==true){
            return true;
        }
        else {
            return false;
        }
    }


    public List<Curso> cursosCredito(Long aLong){
        Optional<Matricula> alumnoMatriculado = matriculaInterface.findById(aLong);
        List<Curso> cursosAlumno= cursoService.findbySemestre(alumnoMatriculado.get().getAlumno().getSemestre());
        return  cursosAlumno;
    }



    @Override
    public List<Matricula> findAll(Sort sort) {
        return null;
    }

    @Override
    public Page<Matricula> findAll(Pageable pageable) {
        return null;
    }

    @Override
    public List<Matricula> findAllById(Iterable<Long> longs) {
        return null;
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(Long aLong) {

    }

    @Override
    public void delete(Matricula entity) {

    }

    @Override
    public void deleteAllById(Iterable<? extends Long> longs) {

    }

    @Override
    public void deleteAll(Iterable<? extends Matricula> entities) {

    }

    @Override
    public void deleteAll() {

    }

    @Override
    public <S extends Matricula> S save(S entity) {
        return matriculaInterface.save(entity);
    }

    @Override
    public <S extends Matricula> List<S> saveAll(Iterable<S> entities) {
        return null;
    }


    @Override
    public boolean existsById(Long aLong) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public <S extends Matricula> S saveAndFlush(S entity) {
        return null;
    }

    @Override
    public <S extends Matricula> List<S> saveAllAndFlush(Iterable<S> entities) {
        return null;
    }

    @Override
    public void deleteAllInBatch(Iterable<Matricula> entities) {

    }

    @Override
    public void deleteAllByIdInBatch(Iterable<Long> longs) {

    }

    @Override
    public void deleteAllInBatch() {

    }

    @Override
    public Matricula getOne(Long aLong) {
        return null;
    }

    @Override
    public Matricula getById(Long aLong) {
        return null;
    }

    @Override
    public Matricula getReferenceById(Long aLong) {
        return null;
    }

    @Override
    public <S extends Matricula> Optional<S> findOne(Example<S> example) {
        return Optional.empty();
    }

    @Override
    public <S extends Matricula> List<S> findAll(Example<S> example) {
        return null;
    }

    @Override
    public <S extends Matricula> List<S> findAll(Example<S> example, Sort sort) {
        return null;
    }

    @Override
    public <S extends Matricula> Page<S> findAll(Example<S> example, Pageable pageable) {
        return null;
    }

    @Override
    public <S extends Matricula> long count(Example<S> example) {
        return 0;
    }

    @Override
    public <S extends Matricula> boolean exists(Example<S> example) {
        return false;
    }

    @Override
    public <S extends Matricula, R> R findBy(Example<S> example, Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction) {
        return null;
    }
}
