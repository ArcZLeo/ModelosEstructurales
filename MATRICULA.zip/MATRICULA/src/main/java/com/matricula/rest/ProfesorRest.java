package com.matricula.rest;

public class ProfesorRest {
}
