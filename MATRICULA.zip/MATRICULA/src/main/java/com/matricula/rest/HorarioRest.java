package com.matricula.rest;


import com.matricula.model.Horario;
import com.matricula.service.HorarioService;
import com.matricula.service.MatriculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/horario/")
public class HorarioRest {

    @Autowired
    private HorarioService horarioService;

    @GetMapping(value = "{id}")
    private ResponseEntity<List<Horario>> ValidarHorario(@PathVariable("id") Long id){

        return ResponseEntity.ok(horarioService.findCurso(id));
    }
}
