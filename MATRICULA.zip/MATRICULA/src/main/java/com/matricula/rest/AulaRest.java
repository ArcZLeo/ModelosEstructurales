package com.matricula.rest;

public class AulaRest {
}
