package com.matricula.rest;


import com.matricula.model.Curso;
import com.matricula.model.Matricula;
import com.matricula.service.MatriculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/matricula/")
public class MatriculaRest {

    @Autowired
    private MatriculaService matriculaService;


    @GetMapping
    private ResponseEntity<List<String>> mostrarMatriculas(){

        return ResponseEntity.ok(matriculaService.findByName());
    }

    @GetMapping(value = "{id}")
    private ResponseEntity<Boolean> validarMatriculaAlumno(@PathVariable("id") Long id){

        return ResponseEntity.ok(matriculaService.validarMatricula(id));
    }

    @GetMapping(value = "cursosDisponible/{id}")
    private ResponseEntity<List<Curso>> validadCursosDisponible(@PathVariable("id") Long id){

        return ResponseEntity.ok(matriculaService.cursosCredito(id));
    }

    @PostMapping
    private ResponseEntity<Matricula> saveDocumento(@RequestBody Matricula documento){
        try {
            if(matriculaService.validarMatricula(documento.getAlumno().getId())==true){
                Matricula matriculaGuardado = matriculaService.save(documento);
                return ResponseEntity.created(new URI("/matricula/"+matriculaGuardado.getId() )).body(matriculaGuardado);
            }
            else{
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}
